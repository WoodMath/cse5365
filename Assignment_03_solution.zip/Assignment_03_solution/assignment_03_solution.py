from tkinter import *
from widgets_03 import *
from graphic_03 import *

ob_root_window = Tk()
ob_root_window.protocol("WM_DELETE_WINDOW", lambda root_window=ob_root_window: close_window_callback(root_window))
ob_root_window.resizable(1,1)
ob_world=cl_world()
cl_widgets(ob_root_window,ob_world)
ob_root_window.mainloop()
